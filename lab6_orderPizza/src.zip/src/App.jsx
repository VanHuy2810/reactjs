
import './App.css'
import Order from './Order/Order'

function App() {

  return (
    <>
     <Order/>
    </>
  )
}

export default App
