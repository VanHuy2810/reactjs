function Form() {
  return (
    <>
      <h1>ReGisform</h1>
      <div>
        <label htmlFor="username">UserName</label>
        <input type="text" id="username" placeholder="nhap" />
      </div>
      <div>
        <label htmlFor="password">PassWord</label>
        <input type="text" id="password" placeholder="nhap" />
      </div>
    </>
  );
}

export default Form;
