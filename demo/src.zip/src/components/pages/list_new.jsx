import Newitem from "./newitem";

function List_new() {
  return (
    <>
      <Newitem />
      <Newitem />
      <Newitem />
    </>
  );
}

export default List_new;
