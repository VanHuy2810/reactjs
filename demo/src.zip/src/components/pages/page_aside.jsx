import List_new from "./list_new";
import Form from "./regisform";

function Aside() {
  return (
    <>
      <Form />
      <List_new />
    </>
  );
}
export default Aside;
