import "./App.css";
import { useState } from "react";
import Ref from "./components/pages/lab3b1";
import Todo from "./components/pages/listtodo/todo";
import TodoLab2 from "./components/pages/listtodo/todo";
// import List_post from "./components/pages/list_post";
// import Aside from "./components/pages/page_aside";

// import Grid from "@mui/material/Unstable_Grid2";

function App() {
  return (
    <>
      {/* <Ref /> */}

      {/* <Todo /> */}
      <TodoLab2 />
    </>
  );
}

export default App;
