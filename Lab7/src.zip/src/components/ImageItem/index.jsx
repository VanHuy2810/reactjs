function ImageItem() {
  return <></>;
}

export default ImageItem;
