function BodyTable({ children }) {
  return <div className="h-[75%]">{children}</div>;
}

export default BodyTable;
